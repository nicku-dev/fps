from werkzeug import urls
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class FreightOrderLine(models.Model):
    _name = 'freight.order.line'
    _description = 'freight.order.license'

    order_id = fields.Many2one('sale.order')

